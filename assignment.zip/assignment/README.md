Link: https://blog-assigment.vercel.app/

To start
```
yarn start
```

Due to time constraint. Cannot apply all the styles I had in mind