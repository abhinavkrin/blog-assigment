export default function Footer({}){
	return (
		<footer>
			Website footer
		</footer>
	)
}